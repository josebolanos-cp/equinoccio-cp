@echo off
REM CP Motion Deck - build de un proyecto (Windows)
REM Uso: build.bat projects\<slug> "Titulo del deck" [es|en]
cd /d "%~dp0"
if "%~1"=="" (echo Falta la carpeta del proyecto & exit /b 1)
if "%~2"=="" (echo Falta el titulo del deck entre comillas & exit /b 1)
set LANG_=%~3
if "%LANG_%"=="" set LANG_=es
if not exist "%~1\media" mkdir "%~1\media"
if not exist "%~1\material" mkdir "%~1\material"
py scripts\build_deck.py --slides "%~1\slides.html" --title "%~2" --out "%~1\deck" --media "%~1\media" "%~1\material" --lang %LANG_%
echo.
echo == Revision de ajuste de texto ==
py scripts\fit_check.py "%~1\deck"
echo.
echo Deck listo para revisar: %~1\deck\index.html
