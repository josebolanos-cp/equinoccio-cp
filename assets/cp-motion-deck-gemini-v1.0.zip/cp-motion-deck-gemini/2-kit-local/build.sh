#!/usr/bin/env bash
# CP Motion Deck · build de un proyecto
# Uso: ./build.sh projects/<slug> "Título del deck" [es|en]
set -euo pipefail
cd "$(dirname "$0")"
P="${1:?Falta la carpeta del proyecto, p. ej. projects/townhall-q4}"
TITLE="${2:?Falta el título del deck entre comillas}"
LANG_="${3:-es}"
[ -f "$P/slides.html" ] || { echo "No existe $P/slides.html (pega ahí el bloque B1 del Gem)"; exit 1; }
mkdir -p "$P/media" "$P/material"
python3 scripts/build_deck.py --slides "$P/slides.html" --title "$TITLE" --out "$P/deck" --media "$P/media" "$P/material" --lang "$LANG_" || STATUS=$?
echo; echo "== Revisión de ajuste de texto =="
python3 scripts/fit_check.py "$P/deck" || true
echo; echo "Deck listo para revisar: $P/deck/index.html"
exit "${STATUS:-0}"
