# Kit local · CP Motion Deck v1.0

El Gem escribe las slides; este kit las convierte en el deck final con el motor, la marca y las validaciones de Content Lab.

```
2-kit-local/
├── setup.sh / setup.bat     # instalar una vez (Python + Pillow; ffmpeg para GIF/video)
├── build.sh / build.bat     # construir un proyecto
├── assets/template.html     # motor de animación (no editar)
├── assets/brand/            # logos oficiales CP
├── scripts/                 # build_deck, qa_check, fit_check, optimize_media, preview_slide
└── projects/
    └── <slug>/
        ├── material/        # archivos originales del cliente
        ├── media/           # archivos optimizados (comandos B2 del Gem)
        ├── slides.html      # bloque B1 del Gem
        └── deck/            # salida: carpeta lista para GitHub
```

Comandos (desde la carpeta 2-kit-local):
- macOS: `./build.sh projects/<slug> "Título" es`
- Windows: `build.bat projects\<slug> "Título" es`
- Media: `python3 scripts/optimize_media.py --help` (Windows: `py scripts\optimize_media.py --help`)
- Vista previa de una slide: `python3 scripts/preview_slide.py projects/<slug>/deck --slide 5 --final --out preview.html`

`qa_check` corre solo al final del build: corrige todo `ERROR` (o pégalo al Gem) y revisa los `WARN`.
