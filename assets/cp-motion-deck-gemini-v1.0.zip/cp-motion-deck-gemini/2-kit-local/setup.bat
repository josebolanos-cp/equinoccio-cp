@echo off
REM Instala lo necesario una sola vez (Windows)
where py >nul 2>nul || (echo Instala Python 3 desde https://www.python.org/downloads/ marcando "Add to PATH" & exit /b 1)
py -m pip install --user --upgrade pillow
where ffmpeg >nul 2>nul || echo AVISO: ffmpeg no esta instalado (necesario para GIF/video): winget install ffmpeg
where node >nul 2>nul || echo AVISO: node no esta instalado (opcional, valida el JavaScript del deck)
echo Listo. Prueba: build.bat projects\ejemplo "Deck de ejemplo"
