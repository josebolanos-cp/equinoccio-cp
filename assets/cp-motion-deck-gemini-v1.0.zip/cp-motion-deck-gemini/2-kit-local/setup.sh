#!/usr/bin/env bash
# Instala lo necesario una sola vez (macOS / Linux)
set -e
command -v python3 >/dev/null || { echo "Instala Python 3: https://www.python.org/downloads/"; exit 1; }
python3 -m pip install --user --upgrade pillow
if ! command -v ffmpeg >/dev/null; then
  echo "AVISO: ffmpeg no está instalado (necesario para GIF/video)."
  echo "  macOS: brew install ffmpeg   ·   Windows: winget install ffmpeg"
fi
command -v node >/dev/null || echo "AVISO: node no está instalado (opcional, valida el JavaScript del deck)."
chmod +x build.sh
echo "Listo. Prueba: ./build.sh projects/ejemplo \"Deck de ejemplo\""
