#!/usr/bin/env python3
"""Assemble a CP motion deck from slide sections + the bundled engine template.

Usage:
  python build_deck.py --slides slides.html --title "Deck title" --out OUT_DIR \
      [--media DIR [DIR ...]] [--lang es|en] [--no-qa]

- slides.html: only <section class="slide ..."> blocks (no <html>, no engine code).
- Every file referenced as  assets/<name>  in the slides is copied into OUT_DIR/assets
  from the --media dirs (first match wins). Brand logos are always copied.
- Writes OUT_DIR/index.html, LEEME.txt (es) or README-deck.txt (en), README.md,
  then runs qa_check.py on the result (unless --no-qa).
"""
import argparse, os, re, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
TEMPLATE = os.path.join(SKILL, 'assets', 'template.html')
BRAND = os.path.join(SKILL, 'assets', 'brand')

HUD_EN = {
    'Clic, espacio o → para avanzar · ← para volver · F pantalla completa':
        'Click, space or → to advance · ← to go back · F for full screen',
    'aria-label="Ir al inicio"': 'aria-label="Go to start"',
    'aria-label="Ir a slide"': 'aria-label="Go to slide"',
    'aria-label="Anterior"': 'aria-label="Previous"',
    'aria-label="Siguiente"': 'aria-label="Next"',
    'aria-label="Pantalla completa"': 'aria-label="Full screen"',
}

def human(n):
    for u in ['B', 'KB', 'MB', 'GB']:
        if n < 1024:
            return f'{n:.0f} {u}'
        n /= 1024
    return f'{n:.1f} TB'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--slides', required=True)
    ap.add_argument('--title', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--media', nargs='*', default=[])
    ap.add_argument('--lang', default='es', choices=['es', 'en'])
    ap.add_argument('--no-qa', action='store_true')
    a = ap.parse_args()

    slides = open(a.slides, encoding='utf-8').read().strip()
    if '<html' in slides.lower() or '<script' in slides.lower():
        sys.exit('slides file must contain only <section class="slide"> blocks (no <html>/<script>)')
    n = len(re.findall(r'<section\s+class="slide', slides))
    if n == 0:
        sys.exit('no <section class="slide"> found in slides file')

    tpl = open(TEMPLATE, encoding='utf-8').read()
    html = (tpl.replace('{{SLIDES}}', slides)
               .replace('{{TITLE}}', a.title)
               .replace('{{LANG}}', a.lang)
               .replace('{{N}}', str(n)))
    if a.lang == 'en':
        for k, v in HUD_EN.items():
            html = html.replace(k, v)

    os.makedirs(os.path.join(a.out, 'assets'), exist_ok=True)
    open(os.path.join(a.out, 'index.html'), 'w', encoding='utf-8').write(html)

    # brand logos always ship
    for f in os.listdir(BRAND):
        shutil.copy2(os.path.join(BRAND, f), os.path.join(a.out, 'assets', f))

    refs = sorted(set(re.findall(r'assets/([\w\-. ]+\.\w+)', slides)))
    missing = []
    for r in refs:
        dst = os.path.join(a.out, 'assets', r)
        if os.path.exists(dst):
            continue
        for d in a.media:
            src = os.path.join(d, r)
            if os.path.exists(src):
                shutil.copy2(src, dst)
                break
        else:
            missing.append(r)

    files = sorted(os.listdir(os.path.join(a.out, 'assets')))
    listing = '\n'.join(f'assets/{f:<34} {human(os.path.getsize(os.path.join(a.out, "assets", f)))}' for f in files)
    if a.lang == 'es':
        readme_name, readme = 'LEEME.txt', f"""{a.title}
Colgate-Palmolive · Content Lab

CÓMO ABRIRLA
1. Mantén juntos index.html y la carpeta assets.
2. Abre index.html con Chrome o Edge.
3. Presiona F para pantalla completa.

CONTROLES
- Avanzar: clic, espacio, flecha derecha o Page Down (clicker)
- Volver: flecha izquierda, Page Up o clic derecho
- Inicio / Final: Home / End · Saltar a un slide: slider del menú (abajo a la derecha)
- Animaciones largas: un clic durante la animación la completa; el siguiente avanza.
- Videos: arrancan al entrar a su slide; clic sobre el video = pausa/reanuda.

TIPOGRAFÍA
DM Sans se carga desde Google Fonts (requiere internet). Sin conexión se usa Arial,
salvo que DM Sans esté instalada en el equipo.

ARCHIVOS
index.html                           Presentación completa ({n} slides)
{listing}
"""
    else:
        readme_name, readme = 'README-deck.txt', f"""{a.title}
Colgate-Palmolive · Content Lab

HOW TO OPEN
1. Keep index.html and the assets folder together.
2. Open index.html in Chrome or Edge.
3. Press F for full screen.

CONTROLS
- Advance: click, space, right arrow or Page Down (clicker)
- Back: left arrow, Page Up or right click
- Start / End: Home / End · Jump: slider in the bottom-right menu
- Long animations: a click during the animation completes it; the next click advances.
- Videos start when their slide opens; click the video to pause/resume.

FILES
index.html                           Full deck ({n} slides)
{listing}
"""
    open(os.path.join(a.out, readme_name), 'w', encoding='utf-8', newline='\r\n').write(readme)
    open(os.path.join(a.out, 'README.md'), 'w', encoding='utf-8').write(
        f'# {a.title}\n\nMotion deck · Colgate-Palmolive Content Lab. Open `index.html` in Chrome or Edge; see `{readme_name}`.\n')

    print(f'built {a.out}/index.html · {n} slides · {len(files)} asset files')
    if missing:
        print('MISSING ASSETS (referenced but not found in --media):')
        for m in missing:
            print('  -', m)
    if not a.no_qa:
        r = subprocess.run([sys.executable, os.path.join(HERE, 'qa_check.py'), a.out])
        sys.exit(r.returncode or (1 if missing else 0))
    sys.exit(1 if missing else 0)

if __name__ == '__main__':
    main()
