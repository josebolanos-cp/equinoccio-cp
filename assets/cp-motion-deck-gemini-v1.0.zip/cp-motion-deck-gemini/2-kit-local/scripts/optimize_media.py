#!/usr/bin/env python3
"""Media prep for motion decks (needs Pillow; ffmpeg/ffprobe for video).

  image IN OUT [--max 1600] [--square] [--quality 82]
      Resize (and optionally centre-crop to 1:1) to a web-friendly JPEG.
      Carousel tiles: --square --max 360. Full-bleed photos: --max 1920.
  gif2mp4 IN OUT [--crop X,Y,W,H] [--width 1110]
      Screen recordings / GIFs -> silent looping MP4 (much smaller). Use --crop to
      remove browser chrome / OS taskbar / screen-share banners.
  video IN OUT [--max-mb 14] [--height 1080]
      Re-encode H.264/AAC with faststart, bitrate chosen to land under --max-mb.
  poster IN.mp4 OUT.jpg [--at 1]
      First-frame poster for <video poster=...>.
  scroll IN [--width 555] [--viewport 444]
      For tall page screenshots used with img.scroll: saves nothing, prints the
      --dist value (negative px) to put in the style attribute.
"""
import argparse, json, subprocess, sys
from PIL import Image

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode:
        sys.exit(r.stderr[-800:])
    return r.stdout

def duration(p):
    out = run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'json', p])
    return float(json.loads(out)['format']['duration'])

def main():
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    i = sp.add_parser('image'); i.add_argument('inp'); i.add_argument('out')
    i.add_argument('--max', type=int, default=1600); i.add_argument('--square', action='store_true'); i.add_argument('--quality', type=int, default=82)
    g = sp.add_parser('gif2mp4'); g.add_argument('inp'); g.add_argument('out'); g.add_argument('--crop'); g.add_argument('--width', type=int, default=1110)
    v = sp.add_parser('video'); v.add_argument('inp'); v.add_argument('out'); v.add_argument('--max-mb', type=float, default=14); v.add_argument('--height', type=int, default=1080)
    po = sp.add_parser('poster'); po.add_argument('inp'); po.add_argument('out'); po.add_argument('--at', type=float, default=1)
    sc = sp.add_parser('scroll'); sc.add_argument('inp'); sc.add_argument('--width', type=int, default=555); sc.add_argument('--viewport', type=int, default=444)
    a = ap.parse_args()

    if a.cmd == 'image':
        im = Image.open(a.inp).convert('RGB')
        if a.square:
            w, h = im.size; s = min(w, h)
            im = im.crop(((w-s)//2, (h-s)//2, (w-s)//2+s, (h-s)//2+s))
        im.thumbnail((a.max, a.max), Image.LANCZOS)
        im.save(a.out, quality=a.quality, optimize=True, progressive=True)
        print(a.out, im.size)
    elif a.cmd == 'gif2mp4':
        vf = []
        if a.crop:
            x, y, w, h = a.crop.split(','); vf.append(f'crop={w}:{h}:{x}:{y}')
        vf += [f'scale={a.width}:-2:flags=lanczos', 'fps=30', 'format=yuv420p']
        run(['ffmpeg', '-y', '-v', 'error', '-i', a.inp, '-vf', ','.join(vf), '-c:v', 'libx264', '-preset', 'slow', '-crf', '24', '-movflags', '+faststart', '-an', a.out])
        print(a.out)
    elif a.cmd == 'video':
        d = duration(a.inp)
        kbps = max(300, int(a.max_mb * 8 * 1024 * 0.93 / d) - 96)
        run(['ffmpeg', '-y', '-v', 'error', '-i', a.inp, '-vf', f'scale=-2:min({a.height}\\,ih)', '-c:v', 'libx264', '-preset', 'medium',
             '-b:v', f'{kbps}k', '-maxrate', f'{int(kbps*1.35)}k', '-bufsize', f'{kbps*2}k', '-pix_fmt', 'yuv420p',
             '-c:a', 'aac', '-b:a', '96k', '-movflags', '+faststart', a.out])
        print(a.out, f'{d:.0f}s @ {kbps}kbps')
    elif a.cmd == 'poster':
        run(['ffmpeg', '-y', '-v', 'error', '-ss', str(a.at), '-i', a.inp, '-frames:v', '1', '-q:v', '5', a.out]); print(a.out)
    elif a.cmd == 'scroll':
        w, h = Image.open(a.inp).size
        shown = h * a.width / w
        print(f'--dist:-{max(0, round(shown - a.viewport))}px')

if __name__ == '__main__':
    main()
