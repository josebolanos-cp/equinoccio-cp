CP Motion Deck · v1.0

# Brief · Motion Deck Content Lab

> Completa este documento y entrégalo junto con los archivos de la carpeta `material/`.
> Una sección `##` por slide. Si no sabes qué tipo elegir, escribe `auto` y Content Lab lo propone.
> Todo dato numérico necesita una fuente (columna **Fuente**). Sin fuente, el dato no entra al deck.

## 0 · Ficha del proyecto

| Campo | Respuesta |
| :--- | :--- |
| Título del deck | |
| Subtítulo / evento | |
| Presentadores (nombre · cargo) | |
| Audiencia (quién, qué sabe, qué le preocupa) | |
| Duración de la charla (min) | |
| Idioma | es / en |
| Objetivo: ¿qué debe pensar, sentir o hacer la audiencia al final? | |
| Fecha de entrega | |
| Repo GitHub de destino (owner/repo) | |

## 1 · Narrativa (una línea cada una)

- **Gancho / pregunta de apertura:**
- **Por qué nosotros (credibilidad):**
- **Bloques de contenido (2–4):**
- **Prueba más fuerte (dato o caso):**
- **Llamado a la acción / qué se llevan:**

## 2 · Slides

Copia este bloque por cada slide.

```
## Slide NN · <título corto>
Tipo: <cover | hook | speakers | statement | agenda | divider | metric | metrics-grid | comparison | process | quote | timeline | screens | gallery | video | ranking | cta | closing | auto>
Titular: <máx. ~8 palabras>
Texto de apoyo: <máx. 2 líneas>
Puntos / datos: <uno por línea>
Builds (orden de aparición con cada clic): <opcional>
Assets: <nombres de archivo en material/>
Notas del presentador: <opcional>
```

## 3 · Datos y fuentes

| Dato | Valor | Fuente (documento, dashboard, fecha) |
| :--- | :--- | :--- |
| | | |

## 4 · Material (carpeta `material/`)

| Archivo | Qué es | Slide |
| :--- | :--- | :--- |
| | foto / captura / video / gif | |

Recomendaciones: fotos de personas en buena resolución (mín. 600 px); capturas de sitios completas (scroll largo) en PNG; videos MP4; GIFs sin barras del navegador si es posible.
