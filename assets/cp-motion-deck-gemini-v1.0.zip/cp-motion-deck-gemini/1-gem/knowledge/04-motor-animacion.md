CP Motion Deck · v1.0

# Motion engine reference

The engine lives in `assets/template.html` (CSS + HUD + JS). Slides only declare *what*
animates and *when*; never add `<script>` or per-slide CSS files — if a component truly needs
new CSS, add a small, prefixed rule block inside the template's `<style>` (in your output copy)
and note it in the delivery summary.

## Stage

Fixed 1920 × 1080 stage scaled to the window. Absolute positioning (`.abs` + `left/top`) on the
brand grid: 80 px side margins, 1760 px content width, 2/3/4-column widths 856 / 555 / 404 px
with 48 px gutters, content between y ≈ 72 (kicker) and y ≈ 960, logo at (80, 984).

## Builds (click-driven)

| Attribute / class | Effect |
| :--- | :--- |
| `class="f" data-s="N"` | Element appears at build step N (0 = on slide entry). Steps must be contiguous from 0. Every click advances one step; after the last step a click moves to the next slide. |
| `data-a="up / down / left / right"` | Slide in from that direction |
| `data-a="blur"` | De-blur + scale in (hero media, big quotes) |
| `data-a="pop"` / `"spin"` | Springy scale-in (orbs, tiles) |
| `data-a="card"` | Rise + rotate in (cards, ranking hero row) |
| `data-a="grow"` / `"growx"` | Scale from bottom / from left (bars, brand beams, skeleton lines) |
| `data-a="hl"` | Highlight marker (`.hl`) or SVG path draw (`.draw`) — no fade |
| `style="--d:.6s"` | Delay within the step. Children inherit `--d` (custom property). |
| `class="split"` on a heading | Letter-by-letter reveal. Use `|` for line breaks. Plain text only. |
| `data-count / data-prefix / data-suffix / data-dec` | Animated counter when the element (or its parent) appears |
| `.draw` + `pathLength="1"` | SVG stroke draws in |
| `.hl` (+ `--hc:var(--green)`, `.g` for dark text) | Highlighter behind a phrase |
| `.ul` | Underline that draws after its word (`--d`) |

**Long timed steps auto-protect themselves.** If a step contains delays ≥ 1.5 s, a click
during the animation *completes it instantly* instead of skipping the slide; the next click
advances. Leaving a slide resets it without reverse transitions, so going back always replays
cleanly.

## Reading pace (statement slides)

For text the audience must read (purpose, manifesto), time reveals to reading, not to clicks:
start ≈ 0.7 s after entry; per word add `0.17 s + 0.032 s × characters`; add 0.18 s after a
comma and 0.30 s after a period. Fire each underline / related graphic when its word is
reached. Keep the text itself fully visible — do **not** fade text word by word (reviewers
found the grey-to-dark effect distracting); only underlines and graphics move.
See `04-purpose-reading.html` (`.rw` spans carry `--d`; `.ul` inherits it).

## Ambient motion (always on while the slide is active)

`.rot / .rotr` (spin, `--dur`), `.bob` (float, `--t`, `--fx`, `--fy`), `.pulse`, `.ripple`
(×3 staggered), `.marquee .track`, `canvas.net`, `canvas.globe`, `#threads`, `.cs` constellation
pieces, `img.scroll`, `.frames` carousels. Everything pauses on inactive slides.

**Loops must be seamless.** Translate by exactly one full period of the pattern (the threads
motif repeats every 1440 px = 3 colours × 2 sweeps × 240 px; a shorter shift visibly jumps).
Carousels duplicate their items once and translate −50 %.

## Media

- `video[data-slide-play]`: plays from 0 with sound when its slide opens, pauses on exit,
  click toggles. Use for reels.
- `video muted loop autoplay playsinline`: silent ambient loop (screen recordings in cards).
- `img.scroll` inside `.shot.media`: simulated page scroll with three pauses and return to top.
  Set `--dist` with `optimize_media.py scroll`, `--dur` 12–16 s.

## HUD

Progress bar (top), control pill (bottom-right: home, slider with slide titles, counter, step
dots, prev/next, full screen), first-run hint. Keys: → / Space / PageDown / Enter next;
← / PageUp / Backspace back; Home / End; F full screen; right-click back; swipe on touch.
`#N` in the URL opens slide N.
