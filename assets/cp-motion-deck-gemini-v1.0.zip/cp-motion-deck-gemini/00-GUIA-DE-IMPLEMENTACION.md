# Guía de implementación · CP Motion Deck en Gemini (app) · v1.0

Content Lab · Colgate-Palmolive

## Cómo funciona

| Quién | Qué hace |
| :--- | :--- |
| **Gem "CP Motion Deck"** (Gemini app) | Lee el brief, revisa la narrativa, elige componentes y escribe `slides.html` + comandos de media |
| **Kit local** (equipo de Content Lab) | Optimiza media, ensambla el deck con el motor fijo, valida marca y calidad |
| **Persona de Content Lab** | Aprueba el plan, revisa el deck en Chrome, entrega la carpeta para GitHub |

La app de Gemini no ejecuta scripts; por eso el motor y las validaciones viven en el kit local. Así cada deck sale con el mismo motor, la misma marca y los mismos controles, sin importar cómo responda el modelo ese día.

## Contenido del zip

```
cp-motion-deck-gemini/
├── 00-GUIA-DE-IMPLEMENTACION.md   ← este archivo
├── 1-gem/
│   ├── instrucciones-del-gem.txt  ← se pega en "Instrucciones" del Gem
│   └── knowledge/                 ← los 7 archivos se suben como "Conocimiento"
├── 2-kit-local/                   ← se instala en cada equipo de Content Lab
└── 3-pruebas/                     ← 3 briefs para la prueba de aceptación (Paso 5)
```

---

## Paso 1 · Preparar el Shared Drive (5 min, una vez)

1. Crea en Google Drive una unidad compartida **CP Motion Deck** (o una carpeta en la unidad de Content Lab).
2. Dentro crea `Gem-conocimiento-v1.0/` y sube los 7 archivos de `1-gem/knowledge/`.
3. Permisos: Content Lab = *Gestor de contenido*; resto = *Lector*.

> Por qué: es la fuente oficial de los archivos del Gem. Si se suben desde Drive, el equipo sabe siempre qué versión usa. (Comprueba en tu organización si el Gem toma los cambios del archivo de Drive automáticamente o si hay que volver a añadirlo; ver Paso 7.)

## Paso 2 · Crear el Gem (10 min, una vez)

1. Abre **gemini.google.com** con tu cuenta de Colgate-Palmolive.
2. Menú lateral → **Explorar Gems** (o *Gem manager*) → **Nuevo Gem**.
3. **Nombre:** `CP Motion Deck · Content Lab`
4. **Descripción:** `Convierte un brief en un motion deck con la marca corporativa CP (diagnóstico, plan y slides.html para el kit local).`
5. **Instrucciones:** abre `1-gem/instrucciones-del-gem.txt`, copia **todo** el texto y pégalo. No lo edites.
6. **Conocimiento:** *Añadir archivos* → desde Drive (`Gem-conocimiento-v1.0/`) o subiendo los 7 archivos:
   `01-marca-cp.md · 02-narrativa.md · 03-catalogo-componentes.md · 04-motor-animacion.md · 05-biblioteca-componentes.txt · 06-plantilla-brief.md · 07-contrato-de-salida.md`
   (Los Gems admiten hasta 10 archivos de conocimiento; usamos 7, quedan 3 libres.)
7. **Guardar**. En la vista previa del Gem escribe: `¿Qué necesitas de mí para hacer un deck?` → debe ofrecer la plantilla de brief. Si responde otra cosa, revisa que estén los 7 archivos.

## Paso 3 · Compartir el Gem con el equipo (2 min)

1. En el Gem → **Compartir** → añade a las personas o al grupo de Content Lab.
2. Recomendado: solo los dueños del servicio pueden **editar**; el resto **usa**.
3. Si no aparece *Compartir*, tu administrador de Workspace lo tiene restringido: pide habilitar el uso compartido de Gems dentro de la organización.

## Paso 4 · Instalar el kit local (10 min por equipo)

1. Copia `2-kit-local/` a una carpeta fija, p. ej. `Documentos/CP-Motion-Deck/`.
2. Instala dependencias una vez:
   - **macOS:** Terminal → `cd Documentos/CP-Motion-Deck` → `bash setup.sh`
   - **Windows:** abre la carpeta → doble clic en `setup.bat`
   (Python 3 es obligatorio; ffmpeg solo para GIF/video; node es opcional.)
3. Prueba con el proyecto de ejemplo incluido:
   - macOS: `./build.sh projects/ejemplo "Bienvenida BEX 2027" es`
   - Windows: `build.bat projects\ejemplo "Bienvenida BEX 2027" es`
4. Debe decir `OK — no issues found` y crear `projects/ejemplo/deck/index.html`. Ábrelo en Chrome y pulsa → para avanzar.

## Paso 5 · Prueba de aceptación (30 min, una vez y en cada nueva versión)

Para cada brief de `3-pruebas/` abre un chat nuevo con el Gem y pégalo. Comprueba:

| Prueba | Debe pasar |
| :--- | :--- |
| `prueba-1-brief-completo.md` | Plan con 12 slides en el orden del brief; ningún dato fuera de la tabla de fuentes; comandos `gif2mp4` para la grabación e `image --square --max 360` para las piezas |
| `prueba-2-brief-con-vacios.md` | El dato `XX%` **no** se pone en pantalla; las capturas que faltan quedan en Pendientes; aparece el 94 % |
| `prueba-3-notas-sueltas-en.md` | Deck en inglés; el 20 % sin confirmar **no** se presenta como hecho; el propósito va literal en inglés; QR y quiz quedan como pendientes |

En las tres: la primera respuesta es solo **diagnóstico + plan** y pregunta por aprobación; tras aprobar, `slides.html` construye sin `ERROR` en el kit. Si alguna falla, no lo pongas en producción: revisa los archivos subidos.

## Paso 6 · Flujo por proyecto (el día a día)

1. **Brief:** envía al cliente `06-plantilla-brief.md` y pídele material en una carpeta.
2. **Proyecto:** crea `projects/<slug>/material/` y copia ahí el material del cliente.
3. **Diagnóstico (Fase A):** en el Gem, pega el brief (y adjunta capturas/imágenes si quieres que verifique lo que muestran). Revisa la narrativa, los datos sin fuente y el plan. Pide cambios o escribe **«Apruebo el plan»**.
4. **Construcción (Fase B):** el Gem entrega 4 bloques:
   - **B1** → guárdalo como `projects/<slug>/slides.html`
   - **B2** → ejecuta los comandos de media (desde la carpeta del kit)
   - **B3** → ejecuta el build
   - **B4** → resumen para el cliente
5. **QA:** si el build muestra `ERROR` o `fit_check` marca algo, pega la salida en el Gem: devolverá solo las slides corregidas (Fase C). Reemplázalas en `slides.html` y vuelve a construir.
6. **Revisión visual:** abre `deck/index.html` en Chrome a pantalla completa (F) y recorre todas las slides con →. Esta revisión es obligatoria antes de entregar.
7. **Entrega:** sube el **contenido** de `projects/<slug>/deck/` al repo del cliente (GitHub → *Add file → Upload files*, máx. 25 MB por archivo) y envía el resumen B4.
8. **Feedback del cliente:** pégalo en el mismo chat del Gem (Fase C) → reemplaza secciones → build → entrega.

## Paso 7 · Gobierno y versiones

- **Fuente de verdad:** el skill `cp-motion-deck` (Claude). El Gem y el kit son una exportación de una versión concreta (`v1.0`, indicada en la primera línea de las instrucciones y de los archivos).
- **Cambios:** nadie edita el Gem ni los archivos sueltos. Se actualiza el skill → se regenera este paquete con nueva versión → se reemplazan los 7 archivos y las instrucciones → se repite el Paso 5 → se anuncia al equipo.
- **Al actualizar archivos de conocimiento:** elimina los antiguos del Gem y añade los nuevos (o confirma que el Gem toma la versión nueva de Drive) y vuelve a hacer la prueba del Paso 2.7.
- **Nuevos componentes:** cuando se diseñe una slide nueva para un cliente, se agrega al skill y entra en la siguiente versión.
- **Registro:** guarda por proyecto `slides.html` + el resumen B4; sirven de ejemplo para mejorar el servicio.

## Límites conocidos

- El Gem no ejecuta código ni ve el deck renderizado: la revisión en Chrome es humana y obligatoria.
- El Gem puede desviarse del contrato (p. ej. inventar un color o un texto); el `qa_check` del kit bloquea los errores de marca y placeholders, pero no juzga el contenido: el diagnóstico de la Fase A hay que leerlo.
- No pidas al Gem el `index.html` completo ni que "lo muestre en Canvas": el motor debe salir siempre del kit para mantener la consistencia.
- Los límites de la app (10 archivos de conocimiento, tamaños, uso compartido) pueden cambiar o estar restringidos por el administrador de Workspace.
