sustainability week talk - notes (Maria, EHS team)

- want something animated like the one Content Lab did for Icesi, for our internal Sustainability Week kickoff, 10 min, audience = all Colgate employees in the Mexico office (english version please, it's going to global too)
- title idea: "Small changes, global impact" or something better
- start w/ who we are (me, Maria Gómez, EHS Manager Mexico + Daniel Ruiz, Sustainability Analyst)
- agenda: 1) why it matters 2) what we did this year 3) what's next 4) recycling quiz
- what we did: we cut water use in the plant a lot this year (I think around 20%? need to confirm), recyclable tubes rollout, solar panels on the warehouse roof
- what's next: zero waste to landfill target
- show our purpose statement somewhere
- end with "join the green team" sign-up (QR code, I'll send it later)
