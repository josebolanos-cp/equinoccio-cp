# Brief · Motion Deck Content Lab

## 0 · Ficha del proyecto
| Campo | Respuesta |
| :--- | :--- |
| Título del deck | Bienvenida BEX 2027 |
| Subtítulo / evento | Onboarding nuevos ingresos · Cali |
| Presentadores | Valentina Chavez · Website Content Specialist LATAM |
| Audiencia | Personas que entran a BEX en enero 2027 |
| Duración | 8 min |
| Idioma | es |
| Objetivo | Que entiendan qué es BEX y cómo trabajamos |
| Repo GitHub de destino | josebolanos-cp/onboarding-bex |

## 1 · Narrativa
- Gancho: auto
- Bloques: 01 Quiénes somos · 02 Cómo trabajamos
- Prueba más fuerte: el 94% de los sitios web de Colgate-Palmolive en el mundo se construyen y gestionan desde Cali.
- Llamado a la acción: Bienvenidos al equipo.

## 2 · Slides

## Slide 01 · Portada
Tipo: cover
Titular: Bienvenida BEX 2027

## Slide 02 · Presentadora
Tipo: speakers
Puntos / datos: Valentina Chavez · Website Content Specialist LATAM · 5 años en BEX
Assets: foto-valentina.png

## Slide 03 · El dato
Tipo: metric
Puntos / datos: 94% de los sitios web de CP en el mundo se construyen y gestionan desde Cali

## Slide 04 · Crecimiento del equipo
Tipo: metric
Puntos / datos: el equipo creció XX% en 2026

## Slide 05 · Nuestro flujo
Tipo: process
Puntos / datos: Brief · Construcción · QA · Publicación

## Slide 06 · Herramientas
Tipo: screens
Assets: captura-cms.png, captura-jira.png

## Slide 07 · Cierre
Tipo: closing
Titular: Bienvenidos al equipo

## 3 · Datos y fuentes
| Dato | Valor | Fuente |
| :--- | :--- | :--- |
| Sitios construidos y gestionados desde Cali | 94% | BEX 2026 |
| Crecimiento del equipo 2026 | XX% | (pendiente) |

## 4 · Material
| Archivo | Qué es | Slide |
| :--- | :--- | :--- |
| foto-valentina.png | foto | 02 |
| captura-cms.png | captura | 06 |
| captura-jira.png | captura | 06 |
