# Brief · Motion Deck Content Lab

## 0 · Ficha del proyecto

| Campo | Respuesta |
| :--- | :--- |
| Título del deck | Contenido que convierte |
| Subtítulo / evento | Town Hall LATAM Marketing · Q4 2026 |
| Presentadores (nombre · cargo) | Jose Bolaños · Digital Content & Creative Coordinator (STA) |
| Audiencia | Equipos de marca LATAM (brand managers, trade). Saben de marca, no de producción digital. Les preocupa que el contenido tarde y no se mida. |
| Duración de la charla (min) | 15 |
| Idioma | es |
| Objetivo | Que los equipos de marca pidan sus piezas digitales a Content Lab y BEX con un brief claro. |
| Fecha de entrega | 2026-11-05 |
| Repo GitHub de destino | josebolanos-cp/townhall-q4 |

## 1 · Narrativa

- **Gancho:** ¿Cuánto tarda hoy tu marca en tener una pieza digital lista para publicar?
- **Por qué nosotros:** Content Lab diseña para el portafolio de CP hace más de 10 años; BEX gestiona los sitios desde Cali.
- **Bloques:** 01 Velocidad · 02 Consistencia de marca · 03 Medición
- **Prueba más fuerte:** Tuhogar.mx fue el #3 sitio más visitado del ecosistema CP en Q3 2026.
- **Llamado a la acción:** Pide tu próxima pieza con el brief de Content Lab.

## 2 · Slides

## Slide 01 · Portada
Tipo: cover
Titular: Contenido que convierte
Texto de apoyo: Town Hall LATAM Marketing · Q4 2026
Puntos / datos: Velocidad · Consistencia · Medición
Assets: —

## Slide 02 · Gancho
Tipo: hook
Titular: ¿Cuánto tarda tu marca en publicar?
Texto de apoyo: Una pieza digital pasa por brief, diseño, aprobación y publicación. Cada paso suma días.
Assets: —

## Slide 03 · Agenda
Tipo: agenda
Puntos / datos: 01 Velocidad — del brief a la pieza · 02 Consistencia — una sola marca en 70+ mercados · 03 Medición — lo que no se mide no mejora
Assets: —

## Slide 04 · Velocidad
Tipo: divider
Titular: Velocidad
Texto de apoyo: Del brief a la pieza publicada.

## Slide 05 · Content Lab en números
Tipo: metrics-grid
Puntos / datos: 4,8/5 satisfacción del cliente · +10 años diseñando para el portafolio de CP · Apego estricto a los ETAs
Assets: pieza-protex.jpg, pieza-hills.jpg, pieza-colgate.jpg (carrusel)

## Slide 06 · Consistencia
Tipo: divider
Titular: Consistencia de marca
Texto de apoyo: Una sola voz en todos los mercados.

## Slide 07 · Escala
Tipo: metrics-grid
Puntos / datos: 600+ sitios web · 70+ mercados · ~40 marcas
Assets: —

## Slide 08 · Lo que hacemos
Tipo: screens
Puntos / datos: Experiencias interactivas (Tu Hogar) · Web admin y campañas (Colgate) · E-commerce e integraciones
Assets: grabacion-tuhogar.gif (tarjeta 1, en loop), sitio-colgate-largo.png (tarjeta 2, con scroll), tarjeta 3 reutiliza sitio-colgate-largo.png
Notas del presentador: la grabación incluye la barra del navegador y la de Windows, recortarlas.

## Slide 09 · Medición
Tipo: divider
Titular: Medición
Texto de apoyo: Lo que no se mide no mejora.

## Slide 10 · Resultado
Tipo: ranking
Titular: El resultado
Puntos / datos: Tuhogar.mx #3 sitio más visitado del ecosistema Colgate-Palmolive en Q3 2026 · por encima de Colgate.com US · solo detrás de Hill's y Hill's e-commerce (US)

## Slide 11 · Cierre
Tipo: cta
Titular: ¿Cuánto tarda tu marca en publicar?
Puntos / datos: Velocidad — un brief claro ahorra semanas · Consistencia — una marca, un sistema · Medición — define el KPI antes de diseñar
Texto de apoyo: Pide tu próxima pieza con el brief de Content Lab.

## Slide 12 · Preguntas
Tipo: closing

## 3 · Datos y fuentes

| Dato | Valor | Fuente |
| :--- | :--- | :--- |
| Satisfacción del cliente Content Lab | 4,8/5 | Encuesta interna Content Lab 2026 |
| Años diseñando para CP | +10 | Content Lab |
| Sitios web gestionados | 600+ | BEX 2026 |
| Mercados | 70+ | BEX 2026 |
| Marcas | ~40 | BEX 2026 |
| Ranking Tuhogar.mx | #3 del ecosistema CP, Q3 2026 | Reporte de tráfico global Q3 2026 |

## 4 · Material

| Archivo | Qué es | Slide |
| :--- | :--- | :--- |
| pieza-protex.jpg | pieza 1:1 | 05 |
| pieza-hills.jpg | pieza 1:1 | 05 |
| pieza-colgate.jpg | pieza 1:1 | 05 |
| grabacion-tuhogar.gif | grabación de pantalla | 08 |
| sitio-colgate-largo.png | captura de página completa | 08 |
